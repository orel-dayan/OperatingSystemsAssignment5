# **Operating System Course Assigment 5**

University assignment 5 for Operating System course in Ariel University.


## **Requirements**
- Ubuntu 22.04 LTS
- GNU C compiler
- Make

## **Getting Started**


```sh

  make all
  ./st_pipeline <SEED>
   ```

## **Authors**
- Orel Dayan
- Evaytar yosef

## **Links:**

- https://jyos-sw.medium.com/blocking-queues-implementation-in-c-7ee9f9e84307

- https://rosettacode.org/wiki/Active_object

- https://stackoverflow.com/questions/44175151/what-is-the-meaning-of-lm-in-gcc


