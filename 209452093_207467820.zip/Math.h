#pragma once
#include <math.h>

int isPrime(unsigned int n);


